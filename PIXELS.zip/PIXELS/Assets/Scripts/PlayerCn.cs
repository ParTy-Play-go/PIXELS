﻿
using UnityEngine;

public class PlayerCn : MonoBehaviour
{

  public float speed = 20f;
  private Rigidbody2D rb;

  private bool faceRight = true;
    void Start()
    {
      rb = GetComponent <Rigidbody2D> ();
    }

    // Update is called once per frame
    void Update()
    {
        float MoveX = Input.GetAxis ("Horizontal");
        rb.MovePosition (rb.position + Vector2.right * MoveX * speed * Time.deltaTime);
    }
}
